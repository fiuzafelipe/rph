#!/bin/bash
clear
echo "=========================================="
echo " CONFIGURACAO AUTOMATICA DO TUNEL SOCKS"
echo " LINUX - SERVIDOR COM INTERNET"
echo "=========================================="
echo

# 1️⃣ CRIAR USUARIO TUNEL COM SENHA
if id "tunel" >/dev/null 2>&1; then
    echo "[OK] Usuario 'tunel' ja existe."
else
    echo "[INFO] Criando usuario 'tunel' com senha..."
    adduser --gecos "" tunel
    echo "tunel:tunel" | chpasswd
    echo "[OK] Usuario 'tunel' criado com senha 'tunel'."
fi

echo

# 2️⃣ CRIAR PASTA .SSH
echo "[INFO] Configurando pasta SSH..."
mkdir -p /home/tunel/.ssh
chmod 700 /home/tunel/.ssh
touch /home/tunel/.ssh/authorized_keys
chmod 600 /home/tunel/.ssh/authorized_keys
chown -R tunel:tunel /home/tunel/.ssh
echo "[OK] Pasta SSH configurada."
echo

# 3️⃣ CRIAR CHAVE SSH AUTOMATICAMENTE (sem senha)
if [ ! -f /home/tunel/.ssh/id_rsa ]; then
    echo "[INFO] Gerando chave privada para tunel..."
    sudo -u tunel ssh-keygen -t rsa -b 2048 -f /home/tunel/.ssh/id_rsa -N ""
    cat /home/tunel/.ssh/id_rsa.pub >> /home/tunel/.ssh/authorized_keys
    chmod 600 /home/tunel/.ssh/authorized_keys
    chown tunel:tunel /home/tunel/.ssh/authorized_keys
    echo "[OK] Chave SSH criada e autorizada."
else
    echo "[OK] Chave SSH ja existe."
fi

echo

# 4️⃣ CONFIGURAR SSHD_CONFIG
echo "=========================================="
echo " ⚙️ CONFIGURACAO DO SSH"
echo "=========================================="
echo "Certifique-se de que o sshd_config tem:"
echo "PubkeyAuthentication yes"
echo "AllowTcpForwarding yes"
echo "PermitTunnel yes"
echo "AllowAgentForwarding yes"
echo
read -p ">>> Pressione ENTER para abrir o sshd_config <<<"
sudo nano /etc/ssh/sshd_config
sudo systemctl restart ssh
echo "[OK] Servico SSH reiniciado."
echo

# 5️⃣ INICIAR TUNEL SOCKS EM BACKGROUND COM LOG
LOG_FILE="/home/tunel/tunel-socks.log"
echo "[INFO] Iniciando tunel SOCKS em background (porta 1080), logs em $LOG_FILE..."
sudo -u tunel nohup ssh -N -D 1080 -i /home/tunel/.ssh/id_rsa tunel@127.0.0.1 \
    -o ExitOnForwardFailure=yes -o ServerAliveInterval=60 >> $LOG_FILE 2>&1 &

# 6️⃣ ESPERAR PORTA 1080 ABRIR
echo "[INFO] Aguardando tunel abrir..."
for i in {1..10}; do
    sleep 1
    if sudo ss -tulnp | grep -q ":1080"; then
        echo "[OK] Tunel SOCKS iniciado na porta 1080."
        break
    fi
    if [ $i -eq 10 ]; then
        echo "[ERRO] Timeout: Tunel SOCKS nao iniciou."
    fi
done

# 7️⃣ TESTE FINAL COM NETSTAT
echo
echo "[INFO] Resultado do netstat para porta 1080:"
sudo netstat -tulnp | grep 1080 || echo "[INFO] Porta 1080 nao encontrada."
echo

echo "=========================================="
echo " ✅ SCRIPT CONCLUIDA - LINUX PDV"
echo
echo "LOG do tunel SOCKS: $LOG_FILE"
echo "Use 'tail -f $LOG_FILE' para acompanhar em tempo real."
echo